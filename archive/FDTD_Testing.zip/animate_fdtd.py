import numpy as np
import matplotlib.pyplot as plt

MAX_FIGSIZE=10

def animateFDTD(n,nx,ny,dx,dy,ez):
    x = np.linspace(0,dx*nx,nx+1)
    y = np.linspace(0,dy*ny,ny+1)
    X,Y = np.meshgrid(x,y)
        
    aspect_ratio = np.ptp(y) / np.ptp(x)

    # Plot using pcolormesh
    # Create a figure and axis instance
    fig, ax = plt.subplots(figsize=(10,10))

    # Plot using pcolormesh with ax object
    pcm = ax.pcolormesh(X, Y, ez.T, shading='gouraud',vmin=-20,vmax=20)  # Create a colormesh plot
    fig.colorbar(pcm, ax=ax)  # Add colorbar linked to the axis
    ax.set_title('Colormesh Plot')
    ax.set_xlabel('X axis')
    ax.set_ylabel('Y axis')
    ax.set_aspect('equal', adjustable='box')
    plt.savefig(f'./plots/iter_{n}.png')
    plt.close(fig)