from fdtd_2d_function import fdtd
import numpy as np

def sinusoidal(t,_):
    return 50*np.sin(1e9*t)

def deriv_gaussian(t,dt):
    spread = 220*dt
    t0 = 600*dt
    amplitude = 100
    return -amplitude*(t0-t)/spread*np.exp(-((t0-t)/spread)**2)

if __name__ == "__main__":
    nx,ny = 1600,1600
    dx = 2.5e-4
    pxstart = 800
    pystart = 1
    wp = 2*np.pi*4e9*np.ones((400,1598))
    nu = 1e9*np.ones((400,1598))
    nsteps = 10000
    input_slices = [(slice(10,11),slice(0,None))]
    poll_slices = []

    _ = fdtd(nx,ny,dx,pxstart,pystart,wp,nu,deriv_gaussian,nsteps,input_slices,poll_slices)
    